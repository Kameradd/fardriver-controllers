#include "tasks.hpp"
#include <HardwareSerial.h>
#include <SPI.h>
#include <SD_MMC.h>
#include <SoftwareSerial.h>
#include <RtcDS1302.h>
#include <cstdio>

HardwareSerial nextionSerial(2);
SoftwareSerial loraSerial(5, 4);

ThreeWire rtcWire(13, 12, 11);
RtcDS1302<ThreeWire> rtc(rtcWire);
File g_logFile;

void displayTask(void *pv) {
    while (1) {
        DisplayUpdate update;
        if (xQueueReceive(g_displayQueue, &update, kDisplayIntervalMs) == pdTRUE) {
            nextionSerial.print("t");
            nextionSerial.print(update.widget_id);
            nextionSerial.print(".txt=\"");
            nextionSerial.print(update.value, 1);
            nextionSerial.print("\"");
            nextionSerial.write(0xFF);
            nextionSerial.write(0xFF);
            nextionSerial.write(0xFF);
        }
    }
}

void initDisplayTask() {
    nextionSerial.begin(9600, SERIAL_8N1, 16, 15);
    xTaskCreatePinnedToCore(displayTask, "Display",
        kStackDisplay, nullptr, kPriorityDisplay,
        &g_displayTask, 1);
}

void loggerTask(void *pv) {
    while (1) {
        LogEntry entry;
        if (xQueueReceive(g_logQueue, &entry, kLoggerIntervalMs) == pdTRUE) {
            if (g_logFile) {
                g_logFile.println(entry.csv_line);
            }
        }
    }
}

void initLoggerTask() {
    if (!SD_MMC.setPins(36, 35, 37, 38, 45, 46)) {
        return;
    }
    if (!SD_MMC.begin("/sdcard", false)) {
        return;
    }
    rtc.Begin();
    if (!rtc.IsDateTimeValid()) {
        rtc.SetDateTime(RtcDateTime(__DATE__, __TIME__));
    }
    rtc.SetIsRunning(true);
    RtcDateTime now = rtc.GetDateTime();
    char filename[32];
    snprintf(filename, sizeof(filename),
             "/LOG_%04u-%02u-%02u_%02u-%02u-%02u.CSV",
             now.Year(), now.Month(), now.Day(),
             now.Hour(), now.Minute(), now.Second());
    g_logFile = SD_MMC.open(filename, FILE_WRITE);
    if (g_logFile) {
        g_logFile.println("Voltage,Current,Speed,Temp");
        g_logFile.flush();
    }

    xTaskCreatePinnedToCore(loggerTask, "Logger",
        kStackLogger, nullptr, kPriorityLogger,
        &g_loggerTask, 1);
}

void loraTask(void *pv) {
    while (1) {
        LoRaPacket packet;
        if (xQueueReceive(g_loraQueue, &packet, kLoRaIntervalMs) == pdTRUE) {
            loraSerial.println(packet.payload);
        }
    }
}

void initLoRaTask() {
    loraSerial.begin(9600);
    xTaskCreatePinnedToCore(loraTask, "LoRa",
        kStackLoRa, nullptr, kPriorityLoRa,
        &g_loraTask, 1);
}
